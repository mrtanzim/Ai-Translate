
import React from 'react';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  noPadding?: boolean;
  intensity?: 'low' | 'medium' | 'high';
}

export const GlassCard: React.FC<GlassCardProps> = ({ 
  children, 
  className = '', 
  noPadding = false,
  intensity = 'medium' 
}) => {
  
  const bgOpacity = {
    low: 'bg-white/40 dark:bg-black/20',
    medium: 'bg-white/60 dark:bg-black/40',
    high: 'bg-white/80 dark:bg-black/60'
  };

  const backdropBlur = {
    low: 'backdrop-blur-sm',
    medium: 'backdrop-blur-md',
    high: 'backdrop-blur-xl'
  };

  return (
    <div
      className={`
        ${bgOpacity[intensity]}
        ${backdropBlur[intensity]}
        border 
        border-white/40 
        dark:border-white/10
        shadow-xl 
        shadow-black/5
        dark:shadow-black/20
        rounded-2xl 
        overflow-hidden
        transition-all duration-300
        ${noPadding ? '' : 'p-6'} 
        ${className}
      `}
    >
      {children}
    </div>
  );
};
